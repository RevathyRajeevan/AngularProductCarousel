import { Product } from "./products.interface";

export interface category{
    name:string,
    product:Product[]
}

