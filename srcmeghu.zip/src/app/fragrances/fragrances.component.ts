import { Component } from '@angular/core';
import { Product } from '../../models/products.interface';

@Component({
  selector: 'app-fragrances',
  standalone: true,
  imports: [],
  templateUrl: './fragrances.component.html',
  styleUrl: './fragrances.component.scss'
})
export class FragrancesComponent {
  beautyProducts: Product[] = [];
 
  constructor() {
    this.fetchData();
  }
 
  async fetchData() {
    const url = 'https://dummyjson.com/products';
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Error: ${response.statusText}`);
      }
      const data = await response.json();
      const beautyProducts = data.products.filter((product: Product) => product.category === 'fragrances');
      this.beautyProducts = beautyProducts.sort((a: { weight: number; }, b: { weight: number; } ) => a.weight - b.weight);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }
}
