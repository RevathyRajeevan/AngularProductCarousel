import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BeautyproductsComponent } from './beautyproducts.component';

describe('BeautyproductsComponent', () => {
  let component: BeautyproductsComponent;
  let fixture: ComponentFixture<BeautyproductsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BeautyproductsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BeautyproductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
