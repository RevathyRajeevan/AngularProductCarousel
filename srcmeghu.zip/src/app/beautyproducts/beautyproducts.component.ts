import { Component } from '@angular/core';
import { Product } from '../../models/products.interface';

@Component({
  selector: 'app-beautyproducts',
  standalone: true,
  imports: [],
  templateUrl: './beautyproducts.component.html',
  styleUrl: './beautyproducts.component.scss'
})
export class BeautyproductsComponent {
  beautyProducts: Product[] = [];
 
  constructor() {
    this.fetchData();
  }
 
  async fetchData() {
    const url = 'https://dummyjson.com/products';
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Error: ${response.statusText}`);
      }
      const data = await response.json();
      const beautyProducts=data.products
      // const beautyProducts = data.products.filter((product: Product) => product.category === 'beauty');
      // this.beautyProducts = beautyProducts.sort((a: { weight: number; }, b: { weight: number; } ) => a.weight - b.weight);
      this.beautyProducts =beautyProducts
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }
}
