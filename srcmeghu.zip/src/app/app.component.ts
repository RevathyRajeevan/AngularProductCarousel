import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
// import { BeautyproductsComponent } from "./beautyproducts/beautyproducts.component";
import { FragrancesComponent } from "./fragrances/fragrances.component";
import { ProductComponent } from "./product/product.component";
import { BeautyproductsComponent } from "./beautyproducts/beautyproducts.component";

@Component({
    selector: 'app-root',
    standalone: true,
    templateUrl: './app.component.html',
    styleUrl: './app.component.scss',
    imports: [RouterOutlet, FragrancesComponent, ProductComponent, BeautyproductsComponent]
})
export class AppComponent {
  title = 'FetchData';
  toFilter:string='';
}
