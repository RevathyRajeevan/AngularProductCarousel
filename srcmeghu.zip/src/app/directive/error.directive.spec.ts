// import { ErrorDirective } from './error.directive';

// describe('ErrorDirective', () => {
//   it('should create an instance', () => {
//     const directive = new ErrorDirective();
//     expect(directive).toBeTruthy();
//   });
// });
